using Microsoft.AspNetCore.Mvc;
using SampleAPIControllers.Models;

namespace SampleAPIControllers.Controllers;

[Route("api/students")]
[ApiController]
public class StudentsController : ControllerBase
{
    private static readonly List<Student> _students= new()
    {
        new Student { IdStudent = 1, FirstName = "John", LastName = "Doe", Address = "Warsaw, Zlota 12", Email = "doe@gmail.com"},
        new Student { IdStudent = 2, FirstName = "Jane", LastName = "Smith", Address = "Warsaw, Koszykowa 86", Email = "smith@gmail.com"},
        new Student { IdStudent = 3, FirstName = "Sam", LastName = "Adams", Address = "Warszawa, Nowy Swiat 67", Email = "adams@gmail.com"},
    }; 
    
    [HttpGet]
    public IActionResult GetStudents()
    {
        return Ok(_students);
    }
    
    [HttpGet("{id:int}")]
    public IActionResult GetStudent(int id)
    {
        var student = _students.FirstOrDefault(st => st.IdStudent == id);
        if (student == null)
        {
            return NotFound($"Student with id {id} was not found");
        }
        
        return Ok(student);
    }
    
    [HttpPost]
    public IActionResult CreateStudent(Student student)
    {
        _students.Add(student);
        return StatusCode(StatusCodes.Status201Created);
    }
    
    [HttpPut("{id:int}")]
    public IActionResult UpdateStudent(int id, Student student)
    {
        var studentToEdit= _students.FirstOrDefault(s => s.IdStudent == id);

        if (studentToEdit == null)
        {
            return NotFound($"Student with id {id} was not found");
        }
        
        _students.Remove(studentToEdit);
        _students.Add(student);
        return NoContent();
    }
    
    [HttpDelete("{id:int}")]
    public IActionResult DeleteStudent(int id)
    {
        var studentToEdit= _students.FirstOrDefault(s => s.IdStudent == id);
        if (studentToEdit == null)
        {
            return NoContent();
        }

        _students.Remove(studentToEdit);
        return NoContent();
    }
    
}